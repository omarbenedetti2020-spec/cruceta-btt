package com.example.cruceta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val sendIntervalMs = 50L // frecuencia de envío mientras se mantiene presionado

    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView

    private var currentChar: Char? = null
    private val repeater = object : Runnable {
        override fun run() {
            currentChar?.let { send(it) }
            if (currentChar != null) ui.postDelayed(this, sendIntervalMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(24, 24, 28))
            setPadding(24, 24, 24, 24)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply {
            text = "Desconectado"
            setTextColor(Color.WHITE)
            textSize = 16f
        }
        val connectBtn = Button(this).apply {
            text = "Conectar"
            setOnClickListener { chooseDevice() }
        }
        top.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(connectBtn)
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val grid = GridLayout(this).apply {
            rowCount = 3
            columnCount = 3
        }
        fun pad(label: String, ch: Char, row: Int, col: Int) {
            val b = Button(this).apply {
                text = label
                textSize = 28f
                setTextColor(Color.WHITE)
                setBackgroundColor(if (ch == 'Z') Color.rgb(200, 60, 60) else Color.rgb(60, 90, 160))
                setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            v.isPressed = true
                            startSending(ch)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            v.isPressed = false
                            stopSending()
                        }
                    }
                    true
                }
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(row, 1f), GridLayout.spec(col, 1f)).apply {
                width = 0; height = 0; setMargins(8, 8, 8, 8)
            }
            grid.addView(b, lp)
        }
        pad("▲", 'F', 0, 1)
        pad("◀", 'L', 1, 0)
        pad("●", 'Z', 1, 1)
        pad("▶", 'R', 1, 2)
        pad("▼", 'B', 2, 1)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        requestBtPermission()
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun chooseDevice() {
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Activa el Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) { requestBtPermission(); return }

        val devices: List<BluetoothDevice> = ad.bondedDevices.toList()
        if (devices.isEmpty()) {
            Toast.makeText(this, "Vincula primero el dispositivo en Ajustes > Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name ?: "?"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige dispositivo")
            .setItems(names) { _, i -> connect(devices[i]) }
            .show()
    }

    private fun connect(device: BluetoothDevice) {
        status.text = "Conectando a ${device.name}..."
        io.execute {
            try {
                close()
                adapter()?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                output = s.outputStream
                ui.post { status.text = "Conectado: ${device.name}" }
            } catch (e: Exception) {
                close()
                ui.post { status.text = "Error al conectar" }
            }
        }
    }

    private fun startSending(c: Char) {
        currentChar = c
        ui.removeCallbacks(repeater)
        ui.post(repeater)
    }

    private fun stopSending() {
        currentChar = null
        ui.removeCallbacks(repeater)
    }

    private fun send(c: Char) {
        io.execute {
            try {
                output?.apply { write(c.code); flush() }
            } catch (e: Exception) {
                close()
                ui.post { status.text = "Conexión perdida" }
            }
        }
    }

    private fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; output = null
    }

    override fun onDestroy() {
        stopSending()
        close()
        io.shutdown()
        super.onDestroy()
    }
}
